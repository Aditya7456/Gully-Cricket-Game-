#include <iostream>
#include<cstring>
#include<cstdlib>
#include<stdlib.h>
#include<ctime>
#include<conio.h>

using namespace std;
#define CLRSCR system("cls")

int scoreA;
int scoreB;
int batsman=0;
int bowler=0;

class Team
{
private:
    char teamname[10];
    char player1[10];
    char player2[10];
    char player3[10];
    string Name[3];

public:
        void group(){
            Name[0]=this->player1;
            Name[1]=this->player2;
            Name[2]=this->player3;
        }   
        
        void randomPlayers(){
            int random;
            srand(time(NULL));
            random=(rand()%3);
            batsman=random;
            bowler =random;
        }
         
        void show_Batman(){
            cout<<this->Name[batsman]<<" is the Batsmen from "<<this->teamname<<endl<<endl;
        }

        void show_bowler(){
            cout<<this->Name[bowler]<<" is the bowler from "<<this->teamname<<endl<<endl;
        }

    Team(char *a, char *b, char *c, char *d) {
        strcpy(this->teamname,a);
        strcpy(this->player1, b);
        strcpy(this->player2, c);
        strcpy(this->player3, d);
    }

    void displayPlayers() {
        cout << "\nPlayer of " << this->teamname << " are :\n"
            << "Player 1 : " << this->player1<<endl
            << "Player 2 : " << this->player2<<endl
            << "Player 3 : " << this->player3<<endl<<endl;
            this->group();
    }

    void game_A(){
        CLRSCR;
        scoreA=0;
        char user;
        srand(time(NULL));
        cout<<"First Innings starts ....\n";

      for (int i = 1; i < 7; i++)
      {   
           int random_score =((rand())%7);
           cout<<this->Name[batsman]<<" Press Space to hit the Ball :\n";
           user=getch();

           if (user== ' ')
           {
               cout<<this->Name[batsman]<<" you scored "<<random_score<<" on "<< i <<" ball\n\n";
               scoreA=scoreA+ random_score;
           }
           else
           {
               cout<<"You entered Wrong Key.\n";
               break;
           }
                    
      }

      cout<<"Team A Score "<<scoreA<<endl;
      
    }

    void game_B()
    {
        CLRSCR;
        scoreB=0;
        char user;
        srand(time(NULL));
        cout<<"\nSecond Innings starts ....\n\n";

      for (int i = 1; i < 7; i++)
      {    int random_score =((rand())%7);
           cout<<this->Name[batsman]<<" Press Space to hit the Ball :\n";
           user=getch();

           if (user== ' ')
           {
               cout<<this->Name[batsman]<<" you scored "<<random_score<<" on "<< i <<" ball\n\n";
                 scoreB=scoreB+ random_score;
           }
           else
           {
               cout<<"You entered Wrong Key.\n";
               break;
           }
                    
      }
      cout<<"Team B Score "<<scoreB<<endl;
      
    }
    void winner_Team(){
        if (scoreA>scoreB)
        {
            cout<<"Team A win the match by "<<scoreA-scoreB<<" runs. ";
        }
        else if (scoreA==scoreB)
        {
            cout<<" Match Draw ";
        }
        else
        {
            cout<<"Team B win the match by "<<scoreB-scoreA<<" runs.";
        }
        getch();
    }
};

int main()
{   
    char TeamA[10] = "TEAM A";
    char player1A[10] = "Rahul";
    char player2A[10] = "Sankar";
    char player3A[10] = "Sachin";
    Team t1(TeamA,player1A,player2A,player3A);

    char TeamB[10] = "TEAM B";
    char player1B[10] = "Aayush";
    char player2B[10] = "Ajay";
    char player3B[10] = "Vijay";
    Team t2(TeamB,player1B,player2B,player3B);

    cout<< "                                       Welcome to the Gully Cricket \n";
    int n;
    cout << "Enter 1 to continue the game...... \n";
    cin >> n;

    if (n == 1) {
        // program Code
        t1.randomPlayers();
        t1.displayPlayers();
        t2.displayPlayers();
        t1.show_Batman();
        t2.show_bowler();
        cout<<"\nPress any key to continue.......";
        getch();
        t1.game_A();
        cout<<"\nPress any key to continue.......\n\n";
        getch();
        t2.show_Batman();
        t1.show_bowler();
         cout<<"\nPress any key to continue.......\n";
        getch();
        t2.game_B();
        cout<<"\nPress any key to continue........\n\n";
        getch();
        t1.winner_Team();

    }
    else
    {
        cout << "Error!..............Please enter only 1.... \n\n";
    }
    getch();
    return 0;
}


